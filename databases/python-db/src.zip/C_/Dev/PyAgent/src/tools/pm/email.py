#!/usr/bin/env python3
"""KPI computation functions for PyAgent."""
# Copyright 2026 PyAgent Authors
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


async def render(template: str, context: dict[str, str]) -> str:
    """Render a simple template by substituting {{key}} with values.

    This is intentionally unsophisticated; templating libraries will be
    considered once the basic tests pass.
    """
    result = template
    for k, v in context.items():
        result = result.replace("{{" + k + "}}", v)
    return result
